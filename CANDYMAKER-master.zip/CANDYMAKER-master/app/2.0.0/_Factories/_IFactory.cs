using <%= namespace %>.Models;
using System.Collections.Generic;

namespace <%= namespace %>.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
        
    }
}