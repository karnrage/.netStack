namespace <%= namespace %>.Models
{
    public abstract class BaseEntity { }


}