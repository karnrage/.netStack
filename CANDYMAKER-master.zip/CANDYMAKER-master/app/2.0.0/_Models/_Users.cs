using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace <%= namespace %>.Models
{
    public class User : BaseEntity
    {
        
    }
}