namespace CNetwork.Models
{
    public abstract class BaseEntity
    {

    }
}