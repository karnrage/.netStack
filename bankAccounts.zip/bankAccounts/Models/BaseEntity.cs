namespace bankAccounts.Models
{
    public abstract class BaseEntity 
    {
        
    }
}