using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
//
using dojoDiner.Models;
using Newtonsoft.Json;

namespace dojoDiner.Controllers
{
    public class HomeController : Controller
    {
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [Route("/Create")]
        public IActionResult CreateProduct(MenuItem newItem)
        {
            if(TryValidateModel(newItem))
            {
                // do something if the model is good
                System.Console.WriteLine("Model is valid");
                // SERIALIZE the object to a string to make it passable through TempData
                TempData["NEW_ITEM"] = JsonConvert.SerializeObject(newItem);
                // No errors, no data to ferry, no problem with view bag.
                return RedirectToAction("Success");
            }
            else
            {
                // do something if the model is no good
                System.Console.WriteLine("The price is wrong, b****");
                ViewBag.errors = ModelState.Values;
                // When we have erros we should NOT redirect... 
                // we should instead render the previous view to show errors 
                // and to allow the user to correct them.
                return View("Index");
            }
        }

        [HttpGet]
        [Route("/success")]
        public IActionResult Success()
        {
            string itemString = TempData["NEW_ITEM"].ToString();
            MenuItem newItem = JsonConvert.DeserializeObject<MenuItem>(itemString);
            ViewBag.newItem = newItem;
            return View();
        }
    }
}
