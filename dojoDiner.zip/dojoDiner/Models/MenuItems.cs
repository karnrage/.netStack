using System.ComponentModel.DataAnnotations;

namespace dojoDiner.Models
{
    public class MenuItem
    {
        [Required]
        [MinLength(3)]
        public string Name { get; set; }

        [Required]
        [Range(.35, 50)]
        public double Price { get; set; }

        [Required]
        [MinLength(3)]
        [MaxLength(255)]
        public string Description { get; set; }

        [Required]
        public bool isVeggo {get; set;}

        [Required]
        public bool isAvailable {get; set;}

        [Required]
        [MinLength(3)]
        public string Category {get; set;}
    }
}