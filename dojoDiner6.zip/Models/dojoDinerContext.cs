using Microsoft.EntityFrameworkCore;
 
namespace dojoDiner.Models
{
    public class dojoDinerContext : DbContext
    {
        // base() calls the parent class' constructor passing the "options" parameter along
        public dojoDinerContext(DbContextOptions<dojoDinerContext> options) : base(options) 
        { }

        public DbSet<MenuItem> MenuItem { get; set; }
        public DbSet<User> User { get; set; }
    }
}