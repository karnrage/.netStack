namespace dojoDiner.Models
{
    public abstract class BaseEntity 
    {
        
    }
}