using System.ComponentModel.DataAnnotations;

namespace dojoDiner.Models
{
    public class User : BaseEntity
    {
        public string firstName {get; set;}
        public string lastName {get; set;}
        public string email {get; set;}
        public string password {get; set;}

    }

    public class LoginViewModel : BaseEntity{
        [Required]
        public string loginEmail {get; set;}
        [Required]
        public string loginPassword {get; set;}
    }

    public class RegisterViewModel : BaseEntity
    {
        [Required]
        public string firstName {get; set;}
        [Required]
        public string lastName {get; set;}
        [Required]
        public string email {get; set;}
        [Required]
        public string regPassword {get; set;}
        [Required]
        public string confirmRegPassword {get; set;}
    }

    //This is a WRAPPER!
    public class LoginRegViewModel : BaseEntity
    {
        public LoginViewModel loginVM {get; set;}
        public RegisterViewModel registerVM {get; set;}
    }

}

