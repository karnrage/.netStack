using trialrun.Models;
using System.Collections.Generic;

namespace trialrun.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
        
    }
}