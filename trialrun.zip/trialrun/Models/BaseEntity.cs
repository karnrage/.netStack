namespace trialrun.Models
{
    public abstract class BaseEntity 
    { 

    }

}