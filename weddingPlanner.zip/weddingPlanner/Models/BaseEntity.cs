namespace weddingPlanner.Models
{
    public abstract class BaseEntity 
    {
        
    }
}